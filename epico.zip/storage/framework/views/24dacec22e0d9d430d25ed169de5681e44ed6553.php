<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Register (* required)</div>

                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label"> Full Name *</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e((old('name'))); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div> <!--end of name -->

                        <div class="form-group<?php echo e($errors->has('user_email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">E-Mail Address *</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div> <!-- end of email -->

                        <div class="form-group<?php echo e($errors->has('birth_date') ? ' has-error' : ''); ?>">
                            <label for="day" class="col-md-4 control-label">Date of birth *</label>
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <select title="day" id="day" class="form-control" name="day" >
                                            <option value="">Day</option>
                                            <?php for($day = 01; $day <= 31; $day++): ?>
                                                <option value="<?php echo e($day); ?>"><?php echo e($day); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                        <?php if($errors->has('day')): ?>
                                            <span class="help-block">
                                        <strong><?php echo e($errors->first('day')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-sm-4">
                                        <select title="month" id="month" class="form-control" name="month">
                                            <option value="">Month</option>
                                            <?php for($month = 01; $month <= 12; $month++): ?>
                                                <option value="<?php echo e($month); ?>"><?php echo e($month); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                        <?php if($errors->has('month')): ?>
                                            <span class="help-block">
                                        <strong><?php echo e($errors->first('month')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="col-sm-4">
                                        <select title="year" id="year" class="form-control" name="year">
                                            <option value="">Year</option>
                                            <?php for($year = 1960; $year <= 2020; $year++): ?>
                                                <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                        <?php if($errors->has('year')): ?>
                                            <span class="help-block">
                                        <strong><?php echo e($errors->first('year')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div> <!-- end of birth_date -->

                        <div class="form-group<?php echo e($errors->has('user_city') ? ' has-error' : ''); ?>">
                            <label for="user_city" class="col-md-4 control-label">City *</label>
                            <div class="col-md-6">
                                <input id="user_city" type="text" class="form-control" name="user_city" value="<?php echo e((old('user_city'))); ?>" required autofocus>

                                <?php if($errors->has('user_city')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('user_city')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div> <!--end of user_city -->

                        <div class="form-group<?php echo e($errors->has('user_country') ? ' has-error' : ''); ?>">
                            <label for="user_country" class="col-md-4 control-label">Country *</label>
                            <div class="col-md-6">
                                <input id="user_country" type="text" class="form-control" name="user_country" value="<?php echo e((old('user_country'))); ?>" required autofocus>

                                <?php if($errors->has('user_country')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('user_country')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div> <!--end of user_country -->

                        <div class="form-group<?php echo e($errors->has('languages') ? ' has-error' : ''); ?>">
                            <label for="languages" class="col-md-4 control-label">Languages *</label>
                            <div class="col-md-6">
                                <input id="languages" type="text" class="form-control" name="languages" value="<?php echo e((old('languages'))); ?>" required autofocus>

                                <?php if($errors->has('languages')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('languages')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div> <!--end of languages -->

                        <div class="form-group<?php echo e($errors->has('competences') ? ' has-error' : ''); ?>">
                            <label for="competences" class="col-md-4 control-label">Competences: PHP, Java etc * </label>
                            <div class="col-md-6">
                                <input id="competences" type="text" class="form-control" name="competences" value="<?php echo e((old('competences'))); ?>" required autofocus>

                                <?php if($errors->has('competences')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('competences')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div> <!--end of competences -->

                        <div class="form-group<?php echo e($errors->has('phone_number') ? ' has-error' : ''); ?>">
                            <label for="phone_number" class="col-md-4 control-label">Mobile Number</label>
                            <div class="col-md-6">
                                <input id="phone_number" type="text" class="form-control"  name="phone_number" value="<?php echo e((old('phone_number'))); ?>" autofocus>

                                <?php if($errors->has('phone_number')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('phone_number')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div> <!--end of phone number -->

                        <div class="form-group">
                            <label for="is_available" class="col-md-4 control-label">Are you available to look for jobs?</label>
                            <div class="col-md-6">
                                <input id="is_available" type="hidden" name="is_available" value="0">
                                <input id="is_available" type="checkbox" class="form-control"  name="is_available" value="1" <?php if(old('is_available')): ?> checked="checked" <?php endif; ?> />

                                <?php if($errors->has('is_available')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('is_available')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div> <!--end of is_available-->

                        <div class="form-group<?php echo e($errors->has('job_type') ? ' has-error' : ''); ?>">
                            <label for="job_type" class="col-md-4 control-label">What kind of Job Seeker are you?</label>
                            <div class="col-md-3">
                                <label for="job_type" class="col-md-4 control-label">Freelancer</label>
                                <input id="is_freelancer" type="checkbox" class="form-control"  name="is_freelancer" value="1" <?php if(old('is_freelancer')): ?> checked="checked" <?php endif; ?> />
                            </div><!--end of freelancer -->
                            <div class="col-md-3">
                                <label for="job_type" class="col-md-4 control-label">Permanent</label>
                                <input id="is_permanent" type="checkbox" class="form-control"  name="is_permanent" value="1" <?php if(old('is_permanent')): ?> checked="checked" <?php endif; ?> />
                            </div><!--end of permanent -->
                        </div> <!--end of job_type-->

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-4 control-label">Password*</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div> <!--end of password -->

                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Confirm Password*</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div> <!-- end of confirm password -->

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Register
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>